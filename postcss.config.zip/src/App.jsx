import { BrowserRouter, Route, Routes } from "react-router-dom"
import AllData from "./Components/AllData"
import DataChart from "./Components/DataChart"


function App() {

  return (
   <>
   <BrowserRouter>
   <Routes>
    <Route path={"/"} element={<AllData/>}/>
    <Route path={"/chart/:id"} element={<DataChart/>}/>
   </Routes>
   </BrowserRouter>
   </>
  )
}

export default App
