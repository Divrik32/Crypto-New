import axios from "axios"

const Base_URL = 'https://api.coingecko.com/api/v3'

export const trendingProducts = async ()=>{
    try {
        const responce = await axios.get(`${Base_URL}/search/trending`)
        return responce.data.coins
    } catch (error) {
      throw error  
    }
}

export const showSingleProduct = async (id)=>{
    try {
        const responce = await axios.get(`${Base_URL}/coins/${id}/market_chart?vs_currency=usd&days=100`)
        return responce.data
    } catch (error) {
        throw error
    }
}