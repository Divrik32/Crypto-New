import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { trendingProducts } from "../Utils/Api";
import { Link } from "react-router-dom";

const AllData = () => {
    const [search , setSearch] = useState({
        search : ''
    });

    const handleChange = (e) => {
        setSearch({ ...search , [e.target.name] : e.target.value });
    };

    const { data, isLoading, isError } = useQuery({
        queryKey: ["allProducts"],
        queryFn: trendingProducts,
    });

    if (isLoading) {
        return <p>Loading...</p>;
    }

    if (isError) {
        return <p>Error...</p>;
    }

    // Filter data based on search input
    const filteredData = data.filter((coin) => 
        coin.item.name.toLowerCase().includes(search.search.toLowerCase())
    );

    return (
        <div className="main-div flex flex-col justify-center items-center bg-black text-white ">
            <div className="h-max">
            <div className="mt-5 mb-5">
                <input
                    type="text"
                    name="search"
                    value={search.search}
                    onChange={handleChange}
                    className="w-[30rem] h-12 text-black rounded-lg border-double focus:border-white"
                    placeholder="Search..."
                />
            </div>

            <div className="text-[2rem] font-sans mt-5 mb-5">Trending Coins</div>

            <div className="overflow-x-auto">
                <table className="min-w-[1000px] w-[700px]">
                    <thead>
                        <tr className="bg-gray-200">
                            <th className="px-6 py-3 text-left text-black">Logo</th>
                            <th className="px-6 py-3 text-left text-black">Name</th>
                            <th className="px-6 py-3 text-left text-black">Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredData.map((coin) => (
                            <tr key={coin.item.id} className="border-b border-gray-200">
                                <td className="px-6 py-4">
                                    <Link to={`/chart/${coin.item.id}`}>
                                        <div className="flex items-center">
                                            <img
                                                src={coin.item.large}
                                                alt=""
                                                style={{ width: "45px", height: "45px" }}
                                                className="rounded-full"
                                            />
                                        </div>
                                    </Link>
                                </td>
                                <td className="px-6 py-4">
                                    <Link to={`/chart/${coin.item.id}`}>
                                        <p className="font-normal mb-1">{coin.item.name}</p>
                                    </Link>
                                </td>
                                <td className="px-6 py-4">
                                    <Link to={`/chart/${coin.item.id}`}>
                                        {coin.item.data.price}
                                    </Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            </div>
            
        </div>
    );
};

export default AllData;
