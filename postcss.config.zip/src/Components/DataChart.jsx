import { useQuery } from '@tanstack/react-query';
import React from 'react';
import { useParams } from 'react-router-dom';
import { showSingleProduct } from '../Utils/Api';
import Chart from 'react-apexcharts'; 
const DataChart = () => {
    const { id } = useParams();

    const { data, isLoading, isError } = useQuery({
        queryKey: ['charts', id],
        queryFn: () => showSingleProduct(id),
        staleTime: 1000 * 60 * 5,
    });

    if (isLoading) {
        return <p>Loading...</p>;
    }

    if (isError) {
        return <p>Error...</p>;
    }

    
    const formattedData = data.prices.map(([timestamp, price]) => ({
        x: new Date(timestamp),
        y: price,
    }));

    // ApexCharts options
    const options = {
        chart: {
            type: 'line',
            height: 550,
        },
        xaxis: {
            type: 'datetime',
        },
    };

    return (
        <div>
            <Chart options={options} series={[{ data: formattedData }]} type="line" height={350} />
        </div>
    );
};

export default DataChart;
